Jangan sok keras Bos
